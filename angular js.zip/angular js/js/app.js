var validationApp = angular.module('validationApp', []);

validationApp.controller('MyCtrl', function ($scope) {

	$scope.submitForm =  function (isValid) {

		if (isValid) {

			alert('our form is amazing');
		}
		 
	};
	
});