<?php
$servername="localhost"; 
$username= "root";
$password="";
$database="angular";
 //creat connection

 $conn=mysqli_connect($servername, $username, $password, $database);
 $data = json_decode(file_get_contents("php://input"));
 if (count($data) > 0)

 	{
 	 $name=mysqli-real-escape-string($conn, $data->name);
 	 $username=mysqli-real-escape-string($conn, $data->username);
 	 $email=mysqli-real-escape-string($conn, $data->email);
 	 $query="INSERT INTO people_tbl(name, username, email) VALUES('$name', '$username', '$email')";

 	 if (mysqli_query($conn, $query)) {
 	 		echo"Data inserted";
 	 	}

 	 	else 
 	 	     {
 	 	     	echo'error';
 	 	     }	
 	}

 //check connection
 if (!$conn) {
	die("connection failed: " . mysqli_connect_error());
}
echo "connected successfully";

?>